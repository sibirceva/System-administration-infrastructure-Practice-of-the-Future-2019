<?php 
use App\Type;
use App\Thing;
$url=$_SERVER['REQUEST_URI'];
header("Refresh: 5; URL=$url");
foreach ($crashes as $crash)
        {
            $crash->who_closed = ($crash->who_closed != NULL) ? 'ADMIN' : $crash->who_closed;
            $crash->thing = Type::find(Thing::find($crash->id_of_thing)->type)->name;
            $crash->loc .= Thing::find($crash->id_of_thing)->location;
			$crash->description ='- ' . str_replace('; ','<br> - ',$crash->description);
			$crash->actions = '<a href="close/'.$crash->id.'">Закрыть</a> | <a href="delete/'.$crash->id.'">Удалить</a>'; /*| <a href="view/'.$crash->id.'">Просмотреть</a>*/
        }
 ?>

<?php $__env->startSection('content'); ?>
<table class="table">
                <caption>&nbsp&nbsp<b><big>Список поломок</big></b></caption>
                <tr>
                    <thead  class="thead-light">
                        <th scope="col">Номер</th>
                        <th scope="col">Вещь и место</th>
                        <th scope="col">Описание</th>
                        <th scope="col">Время заявления</th>
                        <th scope="col">Кто закрыл</th>
                        <th scope="col">Когда закрыта</th>
                        <th scope="col">Действия</th>
                    </thead>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $crashes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crash): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($crash->id); ?></th>
                        <td><?php echo e($crash->thing); ?> <br> <?php echo e($crash->loc); ?></td>
                        <td>
                        <?php 
                            echo $crash->description;
                         ?>
                        </td>
                        <td><?php echo e($crash->time); ?></td>
                        <td><?php echo e($crash->who_closed); ?></td>
                        <td><?php echo e($crash->when_closed); ?></td>
                        <td>
                        <?php 
                            echo $crash->actions;
                         ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <tr><td>Нет поломок</td></tr>
                <?php endif; ?>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>