<?php $__env->startSection('content'); ?>
<table class="table">
                <caption><b>Список поломок</b></caption>
                <tr>
                    <thead  class="thead-light">
                        <th scope="col">Номер</th>
                        <th scope="col">Вещь и место</th>
                        <!-- foreach ... 
                        <th scope="col">Описание</th>
                        <th scope="col">Время заявления</th>
                        <th scope="col">Кто закрыл</th>
                        <th scope="col">Когда закрыта</th>
                        <th scope="col">Действия</th>-->
                    </thead>
                </tr>
        
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>