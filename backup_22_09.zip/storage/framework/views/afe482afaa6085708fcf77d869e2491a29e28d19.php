<?php 

        foreach ($types as $type)
        {
            $type->often_crashes = '- ' . str_replace('; ','<br> - ', $type->often_crashes);
            $type->actions = '<a href="type/things/'.$type->id.'">Просмотреть все вещи этого типа</a> | <a href="edit/'.$type->id.'">Редактировать</a> | <a href="delete/'.$type->id.'">Удалить</a>';
        }
 ?>

<?php $__env->startSection('content'); ?>
<table class="table">
                <caption>&nbsp&nbsp<b><big>Список типов вещей</big></b></caption>
                <tr>
                    <thead  class="thead-light">
                        <th scope="col">Номер</th>
                        <th scope="col">Название</th>
                        <th scope="col">Частые поломки</th>
                        <th scope="col">Действия</th>
                    </thead>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($type->id); ?></th>
                        <td><?php echo e($type->name); ?></td>
                        <td><?php 
                            echo $type->often_crashes;
                         ?>
                        </td>
                        <td>
                        <?php 
                            echo $type->actions;
                         ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <tr><td>Нет типов вещей</td></tr>
                <?php endif; ?>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>