<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        table, td, th {
            border: 1px double black;
        }
    </style>    
</head>
        
<body>
    <table class="table">
        <tr>
            <thead  class="thead-light">
                <th scope="col">Номер</th>
                <th scope="col">Вещь и место</th>
                <th scope="col">Описание</th>
                <th scope="col">Время заявления</th>
            </thead>
        </tr>
        <tr>
            <th scope="row"><?php echo e($crash->id); ?></th>
            <td><?php echo e($crash->obj); ?></td>
			<td><?php echo e($crash->description); ?></td>
			<td><?php echo e($crash->time); ?></td>
        </tr>
        </table>
</body>

</html>