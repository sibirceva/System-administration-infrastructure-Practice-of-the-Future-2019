Номер
Вещь и место
Описание
Время заявления
Кем закрыта
Кто закрыл
Действия

<?php echo e($crash->id); ?>

<?php echo e($crash->obj); ?>

<?php echo e($crash->description); ?>

<?php echo e($crash->time); ?>

<?php echo e($crash->who_closed); ?>

<?php echo e($crash->when_closed); ?>