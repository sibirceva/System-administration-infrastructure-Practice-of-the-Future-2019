<?php 
use App\Type;
        foreach ($things as $thing)
        {
            $thing->type = Type::find($thing->type)->name;
            $thing->actions = '<a href="print_poster/'.$thing->id.'">Печать плаката</a> | <a href="edit/'.$thing->id.'">Редактировать</a> | <a href="delete/'.$thing->id.'">Удалить</a>';
        }
 ?>

<?php $__env->startSection('content'); ?>
<table class="table">
                <caption>&nbsp&nbsp<b><big>Список вещей</big></b></caption>
                <tr>
                    <thead  class="thead-light">
                        <th scope="col">Номер</th>
                        <th scope="col">Тип</th>
                        <th scope="col">Место</th>
                        <th scope="col">Действия</th>
                    </thead>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $things; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thing): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($thing->id); ?></th>
                        <td><?php echo e($thing->type); ?></td>
                        <td><?php echo e($thing->location); ?></td>
                        <td>
                        <?php 
                            echo $thing->actions;
                         ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <tr><td>Нет вещей</td></tr>
                <?php endif; ?>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>