<?php $__env->startSection('content'); ?>
<br><br><p class="text-center h2"><?php echo e($msg); ?><br>[<a href="<?php echo e($link_url); ?>"><?php echo e($link); ?></a>]</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>