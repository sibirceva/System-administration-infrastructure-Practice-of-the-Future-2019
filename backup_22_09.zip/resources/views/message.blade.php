@extends('layouts.app')

@section('content')
<br><br><p class="text-center h2">{{ $msg }}<br>[<a href="{{ $link_url }}">{{$link}}</a>]</p>
@endsection