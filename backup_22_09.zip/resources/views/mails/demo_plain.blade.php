Номер
Вещь и место
Описание
Время заявления

{{ $crash->id }}
{{ $crash->obj }}
{{ $crash->loc }}
{{ $crash->description }}
{{ $crash->time }}