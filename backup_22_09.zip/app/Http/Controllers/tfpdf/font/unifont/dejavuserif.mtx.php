<?php
$name='DejaVuSerif';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-770 -347 2105 1109]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='C:\OSPanel\domains\school\app\Http\Controllers\tfpdf/font/unifont/DejaVuSerif.ttf';
$originalsize=380132;
$fontkey='dejavu';
?>