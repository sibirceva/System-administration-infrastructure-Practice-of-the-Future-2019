<?php
$name='DejaVuSerif-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 939.0,
  'Descent' => -236.0,
  'CapHeight' => 939.0,
  'Flags' => 262148,
  'FontBBox' => '[-836 -389 1854 1145]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='C:\OSPanel\domains\school\app\Http\Controllers\tfpdf/font/unifont/DejaVuSerif-Bold.ttf';
$originalsize=356088;
$fontkey='dejavu';
?>